use `awesome chocolates`;
show tables;

select SaleDate,Amount from sales;