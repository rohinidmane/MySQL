use Company;


select * from employee
Where emp


SELECT emp_name, emp_salary
FROM employees
order by emp_salary desc;